# bits
A Python package to simulate bits.
